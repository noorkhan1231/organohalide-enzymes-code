"""Figure 4. Subfamilies partition among host systems more strongly than families.
usage: python3 fig4_subfamily.py <FINAL dir>
a variance in composition explained by host system: ten-family composition vs subfamily composition within each family
  (sample and study level; PERMANOVA, Bray-Curtis); b indicator subfamilies supported by >= 4 curated genes (multipatt IndVal,
  FDR <= 0.05): dots = share of samples with reads, filled = host system(s) of the indicator combination, with IndVal, curated
  genes and the genome-level lineage control (GTDB order); c mean subfamily composition per host system (samples with reads
  on the family); d abundance of four indicator subfamilies.
"""
import sys, os, re, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from figstyle import *
from matplotlib.patches import Patch
B = sys.argv[1]; T = f'{B}/figures/tmp_fig4'; os.makedirs(T, exist_ok=True); out = f'{B}/figures/Figure_4'
V = pd.read_csv(f'{B}/results/s05_family/main_vegan_tests.csv').set_index('test')
PS = pd.read_csv(f'{B}/results/s06_subfamily/main_subfamily_permanova.csv').set_index('family')
I = pd.read_csv(f'{B}/results/s06_subfamily/main_subfamily_indicators_significant.csv')
L = pd.read_csv(f'{B}/results/s04_build/subfamily_rpkg_long_main.csv')
F = pd.read_csv(f'{B}/results/s04_build/family_rpkg_main.csv')
host = F.set_index('sample_id').host_system
KS = pd.read_csv(f'{B}/results/s06_subfamily/main_subfamily_kruskal.csv')


# ---- p: combined PCoA of all labelled subfamilies
from scipy.stats import chi2
from matplotlib.patches import Ellipse
PC = pd.read_csv(f'{B}/results/s06_subfamily/combined_pcoa_coordinates.csv'); CP = pd.read_csv(f'{B}/results/s06_subfamily/combined_permanova.csv').set_index('level')
fig, ax = plt.subplots(figsize=(84 * MM, 62 * MM)); fig.subplots_adjust(left=0.13, right=0.98, bottom=0.17, top=0.82)
rng_ = np.random.default_rng(2)
for h in HOSTS:
    x = PC[PC.host_system == h]
    ax.scatter(x.PCo1, x.PCo2, s=5, c=COL[h], alpha=0.75, edgecolors='white', linewidths=0.15, label=f'{h} (n = {len(x)})')
for h in HOSTS:
    x = PC[PC.host_system == h]; c = np.cov(x.PCo1, x.PCo2); w, v_ = np.linalg.eigh(c); k = np.sqrt(chi2.ppf(0.95, 2))
    ax.add_patch(Ellipse((x.PCo1.mean(), x.PCo2.mean()), 2 * k * np.sqrt(w[1]), 2 * k * np.sqrt(w[0]), angle=np.degrees(np.arctan2(v_[1, 1], v_[0, 1])), fill=False, ec=COL[h], lw=1.0))
ax.set_xlabel(f'PCo1 ({100 * CP.loc["sample", "PCo1_var"]:.1f}%)'); ax.set_ylabel(f'PCo2 ({100 * CP.loc["sample", "PCo2_var"]:.1f}%)'); ax.spines[['top', 'right']].set_visible(False)
ax.set_ylim(-0.48, 1.0)
ax.legend(loc='lower center', bbox_to_anchor=(0.5, 1.0), ncol=2, frameon=False, markerscale=1.8, handletextpad=0.2, columnspacing=1.0, borderaxespad=0.2)
ax.text(0.98, 0.99, f"PERMANOVA R² = {CP.loc['sample', 'R2']:.3f}, P = {CP.loc['sample', 'P']:.3f}\nPERMDISP F = {CP.loc['sample', 'permdisp_F']:.1f}, P = {CP.loc['sample', 'permdisp_P']:.3f}", transform=ax.transAxes, ha='right', va='top', fontsize=5.4)
fig.savefig(f'{T}/p.pdf'); plt.close(fig)

# ---- a: R2
fams = [f for f in FAM if f in PS.index]
fig, ax = plt.subplots(figsize=(84 * MM, 62 * MM)); fig.subplots_adjust(left=0.2, right=0.97, bottom=0.17, top=0.88)
y = np.arange(len(fams) + 1)
r2s = [V.loc['host_sample', 'R2']] + [PS.loc[f, 'R2'] for f in fams]; r2t = [V.loc['host_study', 'R2']] + [PS.loc[f, 'R2_study'] for f in fams]
pst = [V.loc['host_study', 'P']] + [PS.loc[f, 'P_study'] for f in fams]
ax.barh(y - 0.19, r2s, height=0.36, color='#3B5B8C', label='sample level')
ax.barh(y + 0.19, r2t, height=0.36, color='#9AAFCB', label='study level')
for yi, v, p in zip(y, r2t, pst):
    if p > 0.05: ax.text(v + 0.006, yi + 0.19, 'n.s.', va='center', fontsize=5)
ax.set_yticks(y); ax.set_yticklabels(['All families'] + [f'{f} ({int(PS.loc[f, "n_subfamilies"])})' for f in fams])
ax.get_yticklabels()[0].set_fontweight('bold'); ax.invert_yaxis(); ax.axvline(V.loc['host_sample', 'R2'], color='#3B5B8C', lw=0.5, ls=':')
ax.set_xlabel('Variance explained by host system (R²)'); ax.set_xlim(0, 0.55); ax.spines[['top', 'right']].set_visible(False)
ax.legend(frameon=False, loc='lower center', bbox_to_anchor=(0.45, 1.0), ncol=2, handlelength=1)
fig.savefig(f'{T}/a.pdf'); plt.close(fig)

# ---- b: indicator subfamilies with >= 4 curated genes
J = I[I.n_genes >= 4].copy(); J['fo'] = J.family.map({f: i for i, f in enumerate(FAM)}); J = J.sort_values(['fo', 'stat'], ascending=[True, False])
LV = {'host-associated within lineage': ('host-linked', '#1B7837'), 'not distinguishable from lineage': ('lineage-linked', '#B35806'),
      'not testable within lineage': ('not testable', '#777777'), 'too few carrier genomes': ('too few genomes', '#777777')}
n = len(J); rowh = 3.3
fig = plt.figure(figsize=(88 * MM, (n * rowh + 26) * MM)); ax = fig.add_axes([0.38, 12 / (n * rowh + 26), 0.6, n * rowh / (n * rowh + 26)])
yy = np.arange(n)
for j, h in enumerate(HOSTS):
    pv = J[f'prev_{h}'].values * 100; inc = J.combination.str.split('+').apply(lambda c: h in c).values
    ax.scatter(np.full(n, j)[inc], yy[inc], s=4 + pv[inc] * 1.1, c=COL[h], edgecolors='none', zorder=3)
    ax.scatter(np.full(n, j)[~inc], yy[~inc], s=4 + pv[~inc] * 1.1, facecolors='none', edgecolors='#AAAAAA', linewidths=0.5, zorder=3)
ax.set_xlim(-0.6, 8.8); ax.set_ylim(n - 0.5, -0.5); ax.set_xticks(range(4)); ax.set_xticklabels(HOSTS, rotation=40, ha='left', rotation_mode='anchor'); ax.xaxis.tick_top()
ax.set_yticks(yy); ax.set_yticklabels([re.sub(r'AA1\.Rdh \((\w+)\)', r'\1', s.replace('motifgroup_', 'mg ')) for s in J.subfamily], fontsize=5.6)
ax.tick_params(axis='both', length=0); [s_.set_visible(False) for s_ in ax.spines.values()]
prev_f = None
for i, r in enumerate(J.itertuples()):
    if r.family != prev_f:
        if i > 0: ax.axhline(i - 0.5, color='#CCCCCC', lw=0.5, xmin=-0.95, xmax=1.0, clip_on=False)
        k = (J.family == r.family).sum(); ax.text(-0.33 - 0.0, i + (k - 1) / 2, '', fontsize=5)
        fig.text(0.01, ax.transData.transform((0, i + (k - 1) / 2))[1] / fig.dpi / fig.get_size_inches()[1], r.family, fontsize=5.8, fontweight='bold', va='center')
        prev_f = r.family
    ax.text(3.9, i, f'{r.stat:.2f}', va='center', fontsize=5.4)
    ax.text(6.0, i, f'{r.n_genes}', va='center', fontsize=5.4, ha='right')
    lab, c = LV[r.lineage_order_verdict]; ax.text(6.3, i, lab, va='center', fontsize=5.2, color=c)
for xx, t, ha in [(3.9, 'IndVal', 'left'), (6.0, 'genes', 'right'), (6.3, 'Within-order\ntest', 'left')]:
    ax.text(xx, -1.2, t, fontsize=5.4, fontweight='bold', ha=ha, va='bottom')
ax.text(-0.5, n + 1.2, 'Samples with reads (%)', fontsize=5.2, fontweight='bold', va='center', ha='left', clip_on=False)
for k_, pv in enumerate([10, 50, 100]):
    ax.scatter(-0.2 + k_ * 1.6, n + 2.7, s=4 + pv * 1.1, c='#999999', clip_on=False); ax.text(0.25 + k_ * 1.6, n + 2.7, f'{pv}', va='center', fontsize=5.2)
ax.scatter(5.0, n + 1.2, s=14, c='#666666', clip_on=False); ax.text(5.3, n + 1.2, 'indicator host', va='center', fontsize=5.2)
ax.scatter(5.0, n + 2.7, s=14, facecolors='none', edgecolors='#AAAAAA', linewidths=0.5, clip_on=False); ax.text(5.3, n + 2.7, 'other host', va='center', fontsize=5.2)

fig.savefig(f'{T}/b.pdf'); plt.close(fig)
hb = n * rowh + 26

# ---- c: subfamily composition (mean share among samples with reads on the family)
show = ['RDase', 'GSTDase', 'MetDase', 'VanHase']
fig, axs = plt.subplots(1, 4, figsize=(84 * MM, 72 * MM)); fig.subplots_adjust(left=0.13, right=0.99, bottom=0.45, top=0.91, wspace=0.3)
comp_rows = []; USED = []
_t = plt.get_cmap('tab20').colors; POOL = [_t[i] for i in [0, 2, 4, 6, 8, 10, 12, 16, 18, 1, 3, 5, 7, 9, 11, 17, 19]] + list(plt.get_cmap('tab20b').colors)
for ax, f in zip(axs, show):
    x = L[L.family == f].pivot_table(index='sample_id', columns='subfamily', values='RPKG', aggfunc='sum', fill_value=0)
    x = x[x.sum(axis=1) > 0]; sh = x.div(x.sum(axis=1), axis=0); sh['host'] = sh.index.map(host)
    m = sh.groupby('host').mean().reindex(HOSTS) * 100
    cols = [c for c in m.columns if c != 'unassigned']; cols = sorted(cols, key=lambda c: -m[c].sum())
    cols += ['unassigned'] if 'unassigned' in m.columns else []
    colors = {}
    for c in cols:
        if c == 'unassigned': colors[c] = '#F3E5AB'
        else: colors[c] = POOL[len(USED)]; USED.append(c)
    bottom = np.zeros(4)
    for c in cols:
        v = m[c].fillna(0).values; ax.bar(range(4), v, bottom=bottom, color=colors[c], width=0.75, linewidth=0, label=c.replace('motifgroup_', 'mg ')); bottom += v
    nn = sh.host.value_counts().reindex(HOSTS).fillna(0).astype(int)
    for j in range(4):
        ax.text(j, 101, f'{nn.iloc[j]}', fontsize=4.4, ha='center', va='bottom')
    ax.set_title(f, fontsize=6.2, pad=7); ax.set_xticks(range(4)); ax.set_xticklabels(HOSTS, rotation=90, fontsize=5.2)
    ax.set_ylim(0, 100); ax.spines[['top', 'right']].set_visible(False)
    if f == 'RDase': ax.set_ylabel('Mean share of family reads (%)'); ax.text(-0.7, 101, 'n', fontsize=4.4, ha='right', va='bottom')
    else: ax.set_yticklabels([])
    leg = [Patch(facecolor=colors[c], label=re.sub(r'AA1\.Rdh \((\w+)\)', r'\1', c.replace('motifgroup_', 'mg '))) for c in cols]
    ax.legend(handles=leg, loc='upper left', bbox_to_anchor=(-0.2, -0.5), frameon=False, fontsize=4.4, handlelength=0.7, handletextpad=0.3, labelspacing=0.2, borderaxespad=0)
    m.reset_index().assign(family=f).pipe(comp_rows.append)
fig.savefig(f'{T}/c.pdf'); plt.close(fig)

# ---- d: abundance of four indicator subfamilies (all main-set samples; boxes for samples with reads)
sel = [('RDase', 'motifgroup_CxxCxxCxxxCP'), ('GSTDase', 'motifgroup_SxC'), ('MetDase', 'mecE'), ('VanHase', 'V-BPO_ambiguous')]
fig, axs = plt.subplots(1, 4, figsize=(84 * MM, 58 * MM)); fig.subplots_adjust(left=0.16, right=0.99, bottom=0.3, top=0.8, wspace=0.12)
rng = np.random.default_rng(7); drows = []
for ax, (f, sf) in zip(axs, sel):
    v = L[(L.family == f) & (L.subfamily == sf)].set_index('sample_id').RPKG.reindex(host.index).fillna(0)
    for j, h in enumerate(HOSTS):
        vv = v[host == h]; vp = vv[vv > 0]
        if len(vp) >= 3:
            ax.boxplot(np.log10(vp), positions=[j], widths=0.6, showfliers=False, patch_artist=True, medianprops=dict(color='black', lw=0.6),
                       boxprops=dict(facecolor=COL[h], alpha=0.6, lw=0.4), whiskerprops=dict(lw=0.4), capprops=dict(lw=0.4))
        ax.scatter(j + rng.uniform(-0.2, 0.2, len(vp)), np.log10(vp), s=0.8, c=COL[h], linewidths=0, rasterized=True, zorder=3)
        drows.append(dict(family=f, subfamily=sf, host=h, n=len(vv), n_detected=len(vp), median_detected=vp.median() if len(vp) else np.nan))
    ax.set_xlim(-0.6, 3.6)
    k = KS[(KS.family == f) & (KS.subfamily == sf)].iloc[0]
    ax.set_title(f'{f}\n{sf.replace("motifgroup_", "mg ")}', fontsize=5.6, pad=9)
    ax.set_ylim(-4.5, 3.4); ax.set_xticks(range(4)); ax.set_xticklabels(HOSTS, rotation=90, fontsize=5.2); ax.spines[['top', 'right']].set_visible(False)
    ax.text(0.5, 0.96, ('FDR < 10$^{-100}$' if k.FDR < 1e-100 else 'FDR = ' + (f'{k.FDR:.1e}' if k.FDR < 0.001 else f'{k.FDR:.3f}')), transform=ax.transAxes, ha='center', va='top', fontsize=5)
    if f == 'RDase':
        ax.set_yticks(range(-4, 3)); ax.set_yticklabels([f'$10^{{{t}}}$' for t in range(-4, 3)]); ax.set_ylabel('RPKG')
    else: ax.set_yticks(range(-4, 3)); ax.set_yticklabels([])
fig.savefig(f'{T}/d.pdf'); plt.close(fig)

H = assemble([('a', f'{T}/p.pdf', 0, 0, 84, 62), ('b', f'{T}/a.pdf', 90, 0, 84, 62), ('c', f'{T}/b.pdf', 0, 65, 88, hb),
              ('d', f'{T}/c.pdf', 90, 65, 84, 72), ('e', f'{T}/d.pdf', 90, 139, 84, 58)], out)
print('Figure 4 height mm', round(H, 1), '| indicators shown', n, 'of', len(I))
with pd.ExcelWriter(out + '_source_data.xlsx') as xw:
    PS.reset_index().to_excel(xw, sheet_name='b_subfamily_permanova', index=False); V.reset_index().to_excel(xw, sheet_name='b_family_permanova', index=False)
    I.to_excel(xw, sheet_name='c_all_48_indicators', index=False)
    pd.concat(comp_rows).to_excel(xw, sheet_name='d_mean_share_pct', index=False)
    pd.DataFrame(drows).to_excel(xw, sheet_name='e_summary', index=False); PC.to_excel(xw, sheet_name='a_combined_pcoa', index=False); CP.reset_index().to_excel(xw, sheet_name='a_combined_permanova', index=False); KS.to_excel(xw, sheet_name='e_kruskal_all_subfamilies', index=False)
